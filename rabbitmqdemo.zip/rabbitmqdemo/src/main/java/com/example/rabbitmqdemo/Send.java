package com.example.rabbitmqdemo;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Send {
    private final static String QUEUE_NAME = "hello";


    public static void main(String[] args) {
        ConnectionFactory cf = new ConnectionFactory();
        cf.setHost("localhost");

        try (Connection con = cf.newConnection();
             Channel channel = con.createChannel()
        ) {
            channel.queueDeclare(QUEUE_NAME, false, false, false, null);
            String message = "Hello WOrld!";
            channel.basicPublish("", QUEUE_NAME, null, message.getBytes());
            System.out.println("Sent '"+message+"'");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (TimeoutException t) {
            t.printStackTrace();
        }
    }
}
