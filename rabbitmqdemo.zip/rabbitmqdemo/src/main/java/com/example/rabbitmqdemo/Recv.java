package com.example.rabbitmqdemo;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Recv {
    private final static String QUEUE_NAME = "hello";
    public static void main(String[] args) {
        ConnectionFactory cf = new ConnectionFactory();
        cf.setHost("localhost");
        try (Connection con = cf.newConnection();
             Channel channel = con.createChannel()
        ) {
            channel.queueDeclare(QUEUE_NAME, false, false, false, null);
            System.out.println("Waiting for messages. To exit, press Ctrl+C");

            DeliverCallback deliverCallback = ((consumerTag, message) -> {
                String msg = new String(message.getBody(), "UTF-8");
                System.out.println("Revieved '" + message +"'");

            });
            channel.basicConsume(QUEUE_NAME, true, deliverCallback, consumerTag -> {});
        } catch (IOException e) {
            e.printStackTrace();
        } catch (TimeoutException t) {
            t.printStackTrace();
        }
    }
}
